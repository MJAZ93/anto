#!/bin/sh
# This script wraps the anto call and passes 'validate' as a parameter.
./anto validate
#any extra validation script (like testing script etc) goes here